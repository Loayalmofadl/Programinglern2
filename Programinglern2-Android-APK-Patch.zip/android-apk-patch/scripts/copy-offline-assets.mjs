import { cp, mkdir, access } from 'node:fs/promises';
import path from 'node:path';

const root = process.cwd();
const dist = path.join(root, 'dist');

await mkdir(dist, { recursive: true });

// Vite copies /public automatically. These folders are requested by the
// existing app through absolute URLs and therefore must also be bundled.
for (const folder of ['css', 'js', 'data', 'content']) {
  await access(path.join(root, folder));
  await cp(path.join(root, folder), path.join(dist, folder), { recursive: true, force: true });
}

// The current index.html references this source image by an absolute URL.
await cp(
  path.join(root, 'src', 'assets', 'images'),
  path.join(dist, 'src', 'assets', 'images'),
  { recursive: true, force: true }
);

// The service worker is useful for the hosted PWA build. The Android WebView
// uses its own bundled local assets and intentionally does not register it.
await cp(path.join(root, 'service-worker.js'), path.join(dist, 'service-worker.js'), { force: true });

console.log('Offline assets copied into dist successfully.');
